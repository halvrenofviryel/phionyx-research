# K2 local same-version run

Target: `v0.2.0-beta.1` / `8a6c01ecce457aa94330c0ed7219e4c56ebfe771`.

Harness: **LOCAL_CHECKS_COMPLETED**. External: **EXTERNAL_RESULT_NOT_SUPPLIED**.

This is first-party local regression evidence. No third-party producer, consumer, authorship,
deployment interoperability or independent observation is established by this run.

## Reference producer → reference consumer

Transport: `EVALUATED`. Reconciliation: `{"status": "INCOMPLETE", "counts": {"SATISFIED": 37, "FAILURE": 0, "MISSING": 0, "NOT_EVALUATED": 1, "INDETERMINATE": 0}}`.

Exit zero means evaluation completed; FAILURE, MISSING and NOT_EVALUATED are retained.
The demo observer uses a test policy; it is not an external independent observer.

## Negative controls

| Control | Assertion met |
|---|---|
| byte-tamper | True |
| manifest-target | True |
| wire-version | True |
| control-role | True |
| broken-decision | True |
| toctou-mismatch | True |
| no-receipt | True |
| no-independence-policy | True |

## External lanes

See `run_record.json.external_lanes` for separately retained adapter responses and comparisons.
Absent adapters remain EXTERNAL_RESULT_NOT_SUPPLIED. Projection agreement is a comparison of reported
observations only; a supplied native result without a projection is NOT_COMPARABLE.

## Reproduction and limitations

Every argv, cwd, exit code and complete textual stdout/stderr is retained in run_record.json and logs/.
The binary Git archive is represented by its SHA-256 and exact reproduction command.
Source and dependency pinning is in pins.json. Linux x86-64 / CPython 3.12 wheels are used.
Adapters run as user-supplied local programs, not in a sandbox. A source-file hash does not attest
a complete implementation closure; contributor source, licence and toolchain evidence remains required.
This minimal transport does not support profiles, witnesses or remote deployments.
The release work directory is retained for inspection; it may be removed after review.
